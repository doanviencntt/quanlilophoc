
import React, { useState, useEffect, useMemo } from 'react';
import { ClassGroup, ActivityLog, User, Assignment, Quiz } from './types';
import { INITIAL_CLASSES, INITIAL_QUIZZES, INITIAL_ASSIGNMENTS } from './constants';
import { ClassDashboard } from './components/ClassDashboard';
import { StudentView } from './components/StudentView';
import { AuthView } from './components/AuthView';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('it_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [classes, setClasses] = useState<ClassGroup[]>(() => {
    const saved = localStorage.getItem('informatics_classes');
    return saved ? JSON.parse(saved) : INITIAL_CLASSES;
  });
  
  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('informatics_logs');
    return saved ? JSON.parse(saved) : [];
  });

  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS as any);
  const [quizzes] = useState<Quiz[]>(INITIAL_QUIZZES);

  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    localStorage.setItem('informatics_classes', JSON.stringify(classes));
  }, [classes]);

  useEffect(() => {
    localStorage.setItem('it_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('informatics_logs', JSON.stringify(logs));
  }, [logs]);

  // Anti-cheat detection during exams
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && currentUser?.role === 'student') {
        // Here you would check if they are currently taking an exam
        // For now we log it generally if they're in the app
        addLog({
          type: 'cheat_warning',
          studentId: currentUser.id,
          studentName: currentUser.name,
          classId: 'global',
          reason: 'Học sinh đã chuyển tab/thoát ứng dụng'
        });
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [currentUser]);

  const activeClass = classes.find(c => c.id === selectedClassId);

  const handleLogin = (user: User) => setCurrentUser(user);
  const handleLogout = () => {
    setCurrentUser(null);
    setSelectedClassId(null);
    setShowStats(false);
  };

  const addLog = (logData: Omit<ActivityLog, 'id' | 'timestamp'>) => {
    const newLog: ActivityLog = {
      ...logData,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
    };
    setLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  const handleUpdateClass = (updatedClass: ClassGroup) => {
    setClasses(prev => prev.map(c => c.id === updatedClass.id ? updatedClass : c));
  };

  const handleDeleteClass = (classId: string) => {
    setClasses(prev => prev.filter(c => c.id !== classId));
    setSelectedClassId(null);
    addLog({
      type: 'system',
      studentId: 'admin',
      studentName: 'Admin',
      classId: 'global',
      reason: `Đã xóa lớp học ${classId}`
    });
  };

  const handleCreateClass = () => {
    const newId = `class-${Date.now()}`;
    const newClass: ClassGroup = {
      id: newId,
      name: 'Lớp mới - ' + new Date().getFullYear(),
      grade: '10',
      teacherId: currentUser?.id || 'admin',
      students: [],
      announcements: [],
      schedules: [{ id: 's1', dayOfWeek: 2, period: '1-2', topic: 'Giới thiệu môn học', room: 'Lab' }]
    };
    setClasses([...classes, newClass]);
    setSelectedClassId(newId);
  };

  const handleCompleteQuiz = (quizId: string, score: number) => {
    if (!currentUser?.studentCode) return;
    const quiz = quizzes.find(q => q.id === quizId);
    if (!quiz) return;

    const starsGain = score === quiz.questions.length ? quiz.rewardStars : Math.floor((score/quiz.questions.length) * quiz.rewardStars);
    const xpGain = score * 50;

    const updatedClasses = classes.map(cls => ({
      ...cls,
      students: cls.students.map(s => 
        s.code === currentUser.studentCode 
          ? { ...s, xp: s.xp + xpGain, stars: (s.stars || 0) + starsGain } 
          : s
      )
    }));

    setClasses(updatedClasses);
    addLog({
      type: 'quiz_complete',
      studentId: currentUser.id,
      studentName: currentUser.name,
      classId: 'global',
      stars: starsGain,
      reason: `Hoàn thành thử thách: ${quiz.title} (Nhận ${starsGain} ⭐)`,
    });
  };

  const statsData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    return last7Days.map(date => {
      const dayLogs = logs.filter(l => new Date(l.timestamp).toISOString().split('T')[0] === date);
      return {
        date,
        rewards: dayLogs.filter(l => l.type === 'reward').length,
        penalties: dayLogs.filter(l => l.type === 'penalty').length,
      };
    });
  }, [logs]);

  if (!currentUser) return <AuthView onLogin={handleLogin} allClasses={classes} />;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <nav className="bg-indigo-700 text-white px-8 py-5 shadow-lg sticky top-0 z-[100] backdrop-blur-md bg-opacity-95 border-b border-indigo-600/50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4 cursor-pointer" onClick={() => setSelectedClassId(null)}>
            <div className="bg-white p-2 rounded-[1rem] shadow-inner flex items-center justify-center transform hover:rotate-12 transition-transform">
              <span className="text-xl">💻</span>
            </div>
            <h1 className="text-2xl font-black tracking-tight hidden sm:block">Trợ lý Tin học</h1>
          </div>
          <div className="flex items-center gap-6">
            {(currentUser.role === 'teacher' || currentUser.role === 'admin') && (
              <button 
                onClick={() => setShowStats(!showStats)}
                className="px-6 py-2.5 bg-indigo-600 rounded-2xl hover:bg-indigo-500 transition-all text-sm font-black flex items-center gap-2 border border-indigo-500 shadow-lg shadow-indigo-900/20"
              >
                📊 Thống kê
              </button>
            )}
            <div className="h-10 w-[1px] bg-indigo-500/50 hidden sm:block"></div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-black leading-none mb-1">{currentUser.name}</p>
                <p className="text-[10px] text-indigo-200 font-black uppercase tracking-widest opacity-80">{currentUser.role}</p>
              </div>
              <button onClick={handleLogout} className="p-3 bg-indigo-800 rounded-2xl hover:bg-rose-500 transition-all shadow-lg active:scale-95 group">
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17 16l4-4m0 0l-4-4m4 4H7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6 md:p-8">
        {(currentUser.role === 'teacher' || currentUser.role === 'admin') ? (
          <>
            {!selectedClassId ? (
              <div className="space-y-12 animate-in fade-in duration-700">
                <section>
                  <div className="mb-8 flex justify-between items-end">
                    <div>
                      <h2 className="text-4xl font-black text-slate-800 tracking-tight">Trung tâm Quản lý</h2>
                      <p className="text-slate-400 font-bold mt-2">Dạy học là một nghệ thuật. Chúc bạn một ngày dạy tốt!</p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button 
                        onClick={handleCreateClass}
                        className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-sm shadow-xl hover:bg-indigo-700 transition"
                      >
                        + Tạo lớp học mới
                      </button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {classes.map(cls => (
                      <div 
                        key={cls.id}
                        onClick={() => setSelectedClassId(cls.id)}
                        className="bg-white p-8 rounded-[3rem] border border-slate-200 shadow-sm hover:shadow-2xl hover:-translate-y-3 transition-all cursor-pointer group relative overflow-hidden"
                      >
                        <div className="absolute -top-10 -right-10 w-40 h-40 bg-indigo-50 rounded-full group-hover:scale-150 transition-transform duration-1000 opacity-40 blur-3xl"></div>
                        <div className="relative z-10">
                          <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-4 py-1.5 rounded-full uppercase mb-6 inline-block tracking-widest border border-indigo-100">Khối {cls.grade}</span>
                          <h3 className="text-3xl font-black text-slate-800 mb-2 leading-tight">{cls.name}</h3>
                          <div className="flex items-center gap-2 mb-8 text-slate-400 font-bold text-sm">
                            <span>👥 {cls.students.length} Học sinh</span>
                            <span>•</span>
                            <span>📅 {cls.schedules.length} Buổi học</span>
                          </div>
                          <div className="flex justify-between items-center pt-6 border-t border-slate-100">
                            <span className="text-xs font-black text-indigo-600 uppercase tracking-widest">Quản lý lớp &rarr;</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {showStats && (
                  <section className="animate-in zoom-in-95 duration-500">
                    <div className="bg-white p-12 rounded-[4rem] shadow-2xl border border-slate-100">
                      <div className="flex justify-between items-center mb-12">
                        <h2 className="text-3xl font-black text-slate-800 tracking-tight">Phân tích Hệ thống</h2>
                        <button onClick={() => setShowStats(false)} className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center hover:bg-rose-50 hover:text-rose-500 transition-colors"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg></button>
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 h-[450px]">
                        <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100">
                          <h4 className="text-[10px] font-black text-slate-400 mb-8 uppercase tracking-widest">Tần suất điểm danh</h4>
                          <ResponsiveContainer width="100%" height="80%"><LineChart data={statsData}><XAxis dataKey="date" stroke="#cbd5e1" fontSize={10} axisLine={false} tickLine={false} /><YAxis stroke="#cbd5e1" fontSize={10} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)' }} /><Line type="monotone" dataKey="rewards" stroke="#6366f1" strokeWidth={6} dot={{ r: 8, fill: '#6366f1', strokeWidth: 4, stroke: '#fff' }} /></LineChart></ResponsiveContainer>
                        </div>
                        <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100">
                          <h4 className="text-[10px] font-black text-slate-400 mb-8 uppercase tracking-widest">Cảnh báo gần đây</h4>
                          <div className="space-y-4 max-h-64 overflow-y-auto">
                            {logs.filter(l => l.type === 'cheat_warning').slice(0, 5).map(l => (
                              <div key={l.id} className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3">
                                <span className="text-xl">⚠️</span>
                                <div className="text-xs">
                                  <p className="font-black text-rose-700">{l.studentName}</p>
                                  <p className="text-rose-500">{l.reason}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                )}
              </div>
            ) : (
              <div className="animate-in fade-in slide-in-from-right-10 duration-500">
                <button onClick={() => setSelectedClassId(null)} className="mb-8 flex items-center gap-3 text-indigo-600 font-black hover:gap-5 transition-all uppercase text-xs tracking-widest bg-white w-fit px-6 py-3 rounded-2xl shadow-sm border border-slate-100">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                  Quay lại Trung tâm
                </button>
                {activeClass && (
                  <ClassDashboard 
                    classData={activeClass} 
                    onUpdateClass={handleUpdateClass} 
                    onAddLog={addLog} 
                    onDeleteClass={handleDeleteClass}
                  />
                )}
              </div>
            )}
          </>
        ) : (
          <StudentView 
            user={currentUser} 
            classes={classes} 
            assignments={assignments} 
            quizzes={quizzes} 
            onCompleteQuiz={handleCompleteQuiz}
          />
        )}
      </main>
    </div>
  );
};

export default App;
