
import React, { useState } from 'react';
import { Assignment, Question, QuestionType } from '../types';

interface AssignmentEditorProps {
  onSave: (assignment: Assignment) => void;
  onCancel: () => void;
}

export const AssignmentEditor: React.FC<AssignmentEditorProps> = ({ onSave, onCancel }) => {
  const [assignment, setAssignment] = useState<Partial<Assignment>>({
    title: '',
    description: '',
    type: 'homework',
    startTime: Date.now(),
    endTime: Date.now() + 86400000,
    durationMinutes: 45,
    maxScore: 10,
    questions: []
  });

  const addQuestion = (type: QuestionType) => {
    const newQ: Question = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      prompt: '',
      points: type === 'multiple_choice' ? 0.25 : 1,
      correctAnswer: type === 'true_false' ? true : '',
      options: type === 'multiple_choice' ? ['', '', '', ''] : undefined
    };
    setAssignment(prev => ({ ...prev, questions: [...(prev.questions || []), newQ] }));
  };

  return (
    <div className="fixed inset-0 z-[200] bg-slate-100 overflow-y-auto p-4 md:p-10 animate-in slide-in-from-bottom-10 duration-500">
      <div className="max-w-4xl mx-auto space-y-8 pb-20">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-black text-slate-800">Biên soạn Đề thi/Bài tập</h2>
          <button onClick={onCancel} className="text-slate-400 font-bold hover:text-rose-500">Hủy bỏ</button>
        </div>

        {/* Basic Settings */}
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Tiêu đề đề thi</label>
            <input 
              type="text" 
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl" 
              placeholder="VD: Kiểm tra cuối kì I - Tin học 10"
              value={assignment.title}
              onChange={e => setAssignment({...assignment, title: e.target.value})}
            />
          </div>
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Loại bài</label>
            <select 
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl"
              value={assignment.type}
              onChange={e => setAssignment({...assignment, type: e.target.value as any})}
            >
              <option value="homework">Bài tập về nhà</option>
              <option value="exam">Đề kiểm tra (GDPT 2018)</option>
            </select>
          </div>
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Thời gian làm bài (Phút)</label>
            <input 
              type="number" 
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl" 
              value={assignment.durationMinutes}
              onChange={e => setAssignment({...assignment, durationMinutes: parseInt(e.target.value)})}
            />
          </div>
        </div>

        {/* Questions Builder */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-black text-slate-800">Danh sách câu hỏi</h3>
            <div className="flex gap-2">
              <button onClick={() => addQuestion('multiple_choice')} className="p-2 bg-indigo-50 text-indigo-600 rounded-xl text-[10px] font-black uppercase">Trắc nghiệm</button>
              <button onClick={() => addQuestion('true_false')} className="p-2 bg-emerald-50 text-emerald-600 rounded-xl text-[10px] font-black uppercase">Đúng/Sai</button>
              <button onClick={() => addQuestion('short_answer')} className="p-2 bg-amber-50 text-amber-600 rounded-xl text-[10px] font-black uppercase">Trả lời ngắn</button>
            </div>
          </div>

          {assignment.questions?.map((q, idx) => (
            <div key={q.id} className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-200 space-y-4">
              <div className="flex justify-between items-center">
                <span className="px-3 py-1 bg-slate-100 text-slate-500 rounded-lg text-[10px] font-black uppercase">Câu {idx + 1} - {q.type}</span>
                <button className="text-rose-500 hover:scale-110 transition"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
              </div>
              <textarea 
                className="w-full p-4 bg-slate-50 border border-slate-100 rounded-xl text-sm" 
                placeholder="Nhập nội dung câu hỏi..."
                value={q.prompt}
                onChange={e => {
                  const updated = [...(assignment.questions || [])];
                  updated[idx].prompt = e.target.value;
                  setAssignment({...assignment, questions: updated});
                }}
              />
              {q.type === 'multiple_choice' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {q.options?.map((opt, oIdx) => (
                    <div key={oIdx} className="flex gap-2 items-center">
                      <span className="font-bold text-slate-400">{String.fromCharCode(65 + oIdx)}.</span>
                      <input type="text" className="flex-1 p-2 bg-slate-50 border rounded-lg text-sm" value={opt} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <button 
          onClick={() => onSave(assignment as Assignment)}
          className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black text-xl shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition"
        >
          Lưu Đề thi / Bài tập
        </button>
      </div>
    </div>
  );
};
