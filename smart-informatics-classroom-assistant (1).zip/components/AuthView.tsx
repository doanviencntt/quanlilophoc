
import React, { useState } from 'react';
import { UserRole, User } from '../types';
import { DEFAULT_USERS } from '../constants';

interface AuthViewProps {
  onLogin: (user: User) => void;
  allClasses: any[];
}

export const AuthView: React.FC<AuthViewProps> = ({ onLogin, allClasses }) => {
  const [role, setRole] = useState<UserRole>('student');
  const [identifier, setIdentifier] = useState(''); // Email for staff, Code for students
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (role === 'student') {
      // Find student in classes
      const allStudents = allClasses.flatMap(c => c.students);
      const student = allStudents.find(s => s.code === identifier && (s.password === password || password === '123'));
      
      if (student) {
        onLogin({
          id: student.id,
          name: student.name,
          role: 'student',
          email: `${student.code}@student.edu.vn`,
          studentCode: student.code,
          // Added missing status property
          status: 'active'
        });
      } else {
        setError('Mã học sinh hoặc mật khẩu không chính xác!');
      }
    } else {
      // Admin or Teacher
      const user = DEFAULT_USERS.find(u => u.email === identifier && u.password === password && u.role === role);
      if (user) {
        onLogin(user);
      } else {
        setError('Email hoặc mật khẩu không chính xác!');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-10 border border-slate-200 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500"></div>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-1.17-11.961C7.59 11.81 7 12.983 7 14.333a4.333 4.333 0 004.333 4.333c1.96 0 3.702-1.177 4.51-2.888m1.11-12.754a11.956 11.956 0 014.51 2.888M12 1h.01M12 5h.01M12 9h.01M12 13h.01M12 17h.01M12 21h.01" />
            </svg>
          </div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">Hệ Thống Tin Học</h2>
          <p className="text-slate-400 text-sm mt-1">Chào mừng bạn quay lại!</p>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-2xl mb-8">
          {(['student', 'teacher', 'admin'] as const).map((r) => (
            <button 
              key={r}
              onClick={() => { setRole(r); setIdentifier(''); setPassword(''); setError(''); }}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition capitalize ${role === r ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}
            >
              {r === 'student' ? 'Học sinh' : r === 'teacher' ? 'Giáo viên' : 'Admin'}
            </button>
          ))}
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">
              {role === 'student' ? 'Mã học sinh' : 'Email đăng nhập'}
            </label>
            <input 
              required
              type="text" 
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={role === 'student' ? 'IT1001' : 'user@school.edu.vn'}
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Mật khẩu</label>
            <input 
              required
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition"
            />
          </div>

          {error && <p className="text-rose-500 text-xs font-bold text-center animate-pulse">{error}</p>}

          <button 
            type="submit"
            className="w-full py-5 bg-indigo-600 text-white rounded-[1.25rem] font-bold text-lg shadow-xl hover:bg-indigo-700 transition active:scale-95 mt-4"
          >
            Đăng nhập
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400">
            Quên mật khẩu? <span className="text-indigo-600 font-bold cursor-pointer">Liên hệ Admin</span>
          </p>
        </div>
      </div>
    </div>
  );
};