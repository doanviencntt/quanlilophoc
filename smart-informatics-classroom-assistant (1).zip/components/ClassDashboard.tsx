
import React, { useState, useMemo } from 'react';
import { ClassGroup, Student, ActivityLog, LessonSession, Announcement, Assignment } from '../types';
import { StudentCard } from './StudentCard';
import { LuckyWheel } from './LuckyWheel';

interface ClassDashboardProps {
  classData: ClassGroup;
  onUpdateClass: (updatedClass: ClassGroup) => void;
  onAddLog: (log: Omit<ActivityLog, 'id' | 'timestamp'>) => void;
  onDeleteClass: (classId: string) => void;
}

export const ClassDashboard: React.FC<ClassDashboardProps> = ({ classData, onUpdateClass, onAddLog, onDeleteClass }) => {
  const [activeTab, setActiveTab] = useState<'students' | 'schedule' | 'announcements' | 'assignments' | 'manage'>('students');
  const [selectedSessionId, setSelectedSessionId] = useState<string>(classData.schedules[0]?.id || '');
  const [showLuckyWheel, setShowLuckyWheel] = useState(false);
  
  const [newAnn, setNewAnn] = useState<{ title: string; content: string; priority: 'normal' | 'high' }>({ title: '', content: '', priority: 'normal' });
  const [newSess, setNewSess] = useState({ dayOfWeek: 2, period: '', topic: '', room: '' });

  const currentDate = new Date().toISOString().split('T')[0];
  const attendanceKey = `${currentDate}_${selectedSessionId}`;

  const attendanceStats = useMemo(() => {
    const present = classData.students.filter(s => s.attendance[attendanceKey] === 'present').length;
    const absent = classData.students.filter(s => s.attendance[attendanceKey] === 'absent').length;
    const late = classData.students.filter(s => s.attendance[attendanceKey] === 'late').length;
    return { present, absent, late, total: classData.students.length };
  }, [classData.students, attendanceKey]);

  const handleUpdatePoints = (studentId: string, amount: number, stars: number, reason: string) => {
    const updatedStudents = classData.students.map(s => {
      if (s.id === studentId) {
        return { 
          ...s, 
          points: Math.max(0, s.points + amount),
          stars: Math.max(0, s.stars + stars)
        };
      }
      return s;
    });
    onUpdateClass({ ...classData, students: updatedStudents });
    onAddLog({
      type: amount > 0 || stars > 0 ? 'reward' : 'penalty',
      studentId,
      studentName: classData.students.find(s => s.id === studentId)?.name || '',
      classId: classData.id,
      points: amount,
      stars: stars,
      reason
    });
  };

  const handleAttendance = (studentId: string, status: 'present' | 'absent' | 'late') => {
    const updatedStudents = classData.students.map(s => {
      if (s.id === studentId) {
        return { ...s, attendance: { ...s.attendance, [attendanceKey]: status } };
      }
      return s;
    });
    onUpdateClass({ ...classData, students: updatedStudents });
  };

  const addAnnouncement = () => {
    if (!newAnn.title) return;
    const ann: Announcement = { ...newAnn, id: Math.random().toString(36).substr(2, 9), date: Date.now() };
    onUpdateClass({ ...classData, announcements: [ann, ...classData.announcements] });
    setNewAnn({ title: '', content: '', priority: 'normal' });
  };

  const addSchedule = () => {
    const sess: LessonSession = { ...newSess, id: Math.random().toString(36).substr(2, 9) };
    onUpdateClass({ ...classData, schedules: [...classData.schedules, sess] });
    setNewSess({ dayOfWeek: 2, period: '', topic: '', room: '' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
        <div>
          <h2 className="text-2xl font-black text-slate-800">{classData.name}</h2>
          <p className="text-slate-400 text-sm font-medium">Khối {classData.grade} • {classData.students.length} Học sinh</p>
        </div>
        <div className="flex gap-1 bg-slate-100 p-1.5 rounded-[1.25rem] overflow-x-auto no-scrollbar">
          {['students', 'schedule', 'announcements', 'assignments', 'manage'].map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-5 py-2.5 rounded-xl text-xs font-black transition capitalize whitespace-nowrap ${activeTab === tab ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {tab === 'students' ? 'Điểm danh' : tab === 'schedule' ? 'Lịch dạy' : tab === 'announcements' ? 'Thông báo' : tab === 'assignments' ? 'Bài tập' : 'Quản lý'}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'students' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex flex-col md:flex-row items-center gap-4 bg-indigo-50 p-6 rounded-[2rem] border border-indigo-100">
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-indigo-700">Buổi học:</span>
              <select 
                value={selectedSessionId}
                onChange={(e) => setSelectedSessionId(e.target.value)}
                className="bg-white border border-indigo-200 px-4 py-2 rounded-xl text-sm font-bold text-indigo-600 outline-none"
              >
                {classData.schedules.map(s => (
                  <option key={s.id} value={s.id}>T{s.dayOfWeek} - Tiết {s.period} ({s.topic})</option>
                ))}
              </select>
            </div>
            
            <div className="h-10 w-[1px] bg-indigo-200 hidden md:block mx-2"></div>

            <div className="flex-1 flex justify-around gap-6">
              <div className="text-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Có mặt</p>
                <p className="text-xl font-black text-emerald-600">{attendanceStats.present}</p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Vắng mặt</p>
                <p className="text-xl font-black text-rose-600">{attendanceStats.absent}</p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Vào muộn</p>
                <p className="text-xl font-black text-amber-600">{attendanceStats.late}</p>
              </div>
            </div>

            <button 
              onClick={() => setShowLuckyWheel(true)}
              className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-xs shadow-lg hover:bg-indigo-700 transition flex items-center gap-2"
            >
              🎡 Gọi phát biểu
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {classData.students.map(student => (
              <StudentCard 
                key={student.id} 
                student={student} 
                currentDate={attendanceKey}
                onUpdatePoints={(id, amt, reason) => handleUpdatePoints(id, amt, 0, reason)}
                onAttendance={handleAttendance}
              />
            ))}
          </div>
        </div>
      )}

      {activeTab === 'manage' && (
        <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-10 animate-in fade-in duration-500">
          <div>
            <h3 className="text-xl font-black text-slate-800 mb-6 flex justify-between items-center">
              Nguy hiểm
              <button 
                onClick={() => { if(confirm('Bạn có chắc chắn muốn xóa lớp này?')) onDeleteClass(classData.id); }}
                className="px-6 py-2 bg-rose-50 text-rose-600 border border-rose-200 rounded-xl text-xs font-black hover:bg-rose-600 hover:text-white transition"
              >
                Xóa lớp học
              </button>
            </h3>
            <p className="text-slate-400 text-sm">Xóa toàn bộ dữ liệu lớp học, bao gồm học sinh, điểm số và thông báo. Hành động này không thể hoàn tác.</p>
          </div>

          <div className="pt-10 border-t border-slate-100">
             <h3 className="text-xl font-black text-slate-800 mb-6">Cập nhật danh sách học sinh</h3>
             <textarea 
               placeholder="Dán danh sách học sinh mới tại đây (Tên, Mã số)..."
               className="w-full h-40 p-5 bg-slate-50 border border-slate-200 rounded-3xl resize-none font-mono text-sm mb-4"
             />
             <button className="px-8 py-3 bg-indigo-600 text-white rounded-2xl font-black text-xs hover:bg-indigo-700 shadow-lg transition">Lưu danh sách</button>
          </div>
        </div>
      )}

      {/* Other tabs remain largely the same, but you can add assignment time logic in Assignments tab */}

      {showLuckyWheel && (
        <LuckyWheel 
          students={classData.students} 
          onClose={() => setShowLuckyWheel(false)}
          onResult={(s) => {
            handleUpdatePoints(s.id, 0, 1, 'May mắn gọi tên & Phát biểu');
            setShowLuckyWheel(false);
          }}
        />
      )}
    </div>
  );
};
