
import React, { useState, useEffect } from 'react';
import { Quiz, QuizQuestion } from '../types';

interface GameQuizProps {
  quiz: Quiz;
  onComplete: (score: number, total: number) => void;
  onCancel: () => void;
}

export const GameQuiz: React.FC<GameQuizProps> = ({ quiz, onComplete, onCancel }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [gameOver, setGameOver] = useState(false);

  const currentQuestion = quiz.questions[currentIdx];

  useEffect(() => {
    if (gameOver || timeLeft <= 0) {
      if (timeLeft <= 0) handleAnswer(-1);
      return;
    }
    const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, gameOver]);

  const handleAnswer = (idx: number) => {
    if (idx === currentQuestion.correctIndex) {
      setScore(prev => prev + 1);
    }

    if (currentIdx < quiz.questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
      setTimeLeft(15);
    } else {
      setGameOver(true);
    }
  };

  if (gameOver) {
    const starReward = score === quiz.questions.length ? quiz.rewardStars : Math.floor((score/quiz.questions.length) * quiz.rewardStars);
    
    return (
      <div className="bg-slate-900 text-white p-12 rounded-[3rem] text-center space-y-8 shadow-2xl border border-white/10 animate-in zoom-in duration-500 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500/20 via-transparent to-transparent"></div>
        <div className="relative z-10">
          <div className="text-7xl mb-6">🏆</div>
          <h2 className="text-4xl font-black tracking-tight mb-2">Thử thách hoàn tất!</h2>
          <p className="text-slate-400 font-medium">Bạn đã trả lời đúng {score}/{quiz.questions.length} câu hỏi.</p>
          
          <div className="py-10">
            <div className="text-sm font-black text-amber-400 uppercase tracking-widest mb-2">Phần thưởng của bạn</div>
            <div className="text-6xl font-black flex items-center justify-center gap-3 drop-shadow-[0_0_15px_rgba(251,191,36,0.5)]">
               <span className="text-amber-400">⭐</span> {starReward}
            </div>
          </div>

          <button 
            onClick={() => onComplete(score, quiz.questions.length)}
            className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 rounded-2xl font-black text-lg transition-all shadow-xl shadow-indigo-500/20 active:scale-95"
          >
            Nhận Sao & Thoát
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 text-white p-8 md:p-12 rounded-[3rem] shadow-2xl border border-white/5 max-w-2xl mx-auto overflow-hidden relative">
      <div className="absolute top-0 left-0 h-1.5 bg-indigo-500 transition-all duration-1000 ease-linear shadow-[0_0_15px_rgba(99,102,241,0.5)]" style={{ width: `${(timeLeft / 15) * 100}%` }}></div>
      
      <div className="flex justify-between items-center mb-10">
        <div className="px-4 py-1.5 bg-white/5 rounded-full border border-white/10">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Câu {currentIdx + 1}/{quiz.questions.length}</span>
        </div>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-mono font-black text-xl border-2 ${timeLeft < 5 ? 'border-rose-500 text-rose-500 animate-pulse' : 'border-indigo-500 text-indigo-400'}`}>
            {timeLeft}
          </div>
        </div>
      </div>

      <h3 className="text-2xl md:text-3xl font-black mb-12 leading-tight text-white drop-shadow-sm">{currentQuestion.question}</h3>

      <div className="grid grid-cols-1 gap-4">
        {currentQuestion.options.map((option, i) => (
          <button
            key={i}
            onClick={() => handleAnswer(i)}
            className="group relative flex items-center p-5 bg-white/5 border border-white/10 rounded-[1.5rem] hover:bg-white/10 hover:border-indigo-500/50 transition-all text-left active:scale-98"
          >
            <span className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mr-5 group-hover:bg-indigo-600 group-hover:text-white font-black transition-colors text-slate-400 border border-white/5">
              {String.fromCharCode(65 + i)}
            </span>
            <span className="flex-1 font-bold text-slate-200">{option}</span>
          </button>
        ))}
      </div>

      <button onClick={onCancel} className="mt-10 text-slate-500 hover:text-rose-500 text-xs font-black transition-colors uppercase tracking-widest w-full">Dừng chơi</button>
    </div>
  );
};
