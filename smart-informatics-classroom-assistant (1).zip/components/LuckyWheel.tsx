
import React, { useState, useEffect } from 'react';
import { Student } from '../types';

interface LuckyWheelProps {
  students: Student[];
  onResult: (student: Student) => void;
  onClose: () => void;
}

export const LuckyWheel: React.FC<LuckyWheelProps> = ({ students, onResult, onClose }) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [winner, setWinner] = useState<Student | null>(null);

  const spin = () => {
    if (isSpinning || students.length === 0) return;
    setIsSpinning(true);
    setWinner(null);
    
    const newRotation = rotation + 1440 + Math.random() * 360;
    setRotation(newRotation);

    setTimeout(() => {
      setIsSpinning(false);
      const actualRotation = newRotation % 360;
      const sliceSize = 360 / students.length;
      const winningIndex = Math.floor((360 - actualRotation) / sliceSize) % students.length;
      const selected = students[winningIndex];
      setWinner(selected);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-lg rounded-[3rem] p-8 shadow-2xl flex flex-col items-center relative overflow-hidden">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-rose-500 transition">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <h3 className="text-2xl font-black text-slate-800 mb-8 uppercase tracking-widest">Vòng quay may mắn</h3>

        <div className="relative w-64 h-64 mb-10 group">
          {/* Needle */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-4 z-20">
            <div className="w-8 h-8 bg-rose-500 rounded-full shadow-lg border-4 border-white flex items-center justify-center">
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[10px] border-t-white mt-4"></div>
            </div>
          </div>

          {/* Wheel Canvas Container */}
          <div 
            className="w-full h-full rounded-full border-8 border-slate-100 shadow-xl overflow-hidden transition-transform duration-[4000ms] cubic-bezier(0.15, 0, 0.15, 1)"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {students.map((s, i) => {
                const angle = 360 / students.length;
                const startAngle = i * angle;
                const x1 = 50 + 50 * Math.cos((Math.PI * startAngle) / 180);
                const y1 = 50 + 50 * Math.sin((Math.PI * startAngle) / 180);
                const x2 = 50 + 50 * Math.cos((Math.PI * (startAngle + angle)) / 180);
                const y2 = 50 + 50 * Math.sin((Math.PI * (startAngle + angle)) / 180);
                
                return (
                  <path
                    key={s.id}
                    d={`M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`}
                    fill={i % 2 === 0 ? '#6366f1' : '#f59e0b'}
                    stroke="white"
                    strokeWidth="0.5"
                  />
                );
              })}
            </svg>
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-12 h-12 bg-white rounded-full shadow-inner border-2 border-slate-100"></div>
          </div>
        </div>

        {winner ? (
          <div className="text-center animate-in zoom-in duration-300">
            <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest mb-2">Người may mắn là:</p>
            <h4 className="text-4xl font-black text-indigo-600 mb-6">{winner.name}</h4>
            <div className="flex gap-4">
              <button onClick={() => onResult(winner)} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black shadow-lg hover:bg-indigo-700 transition">Tặng 1⭐</button>
              <button onClick={spin} className="px-6 py-3 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition">Quay lại</button>
            </div>
          </div>
        ) : (
          <button 
            disabled={isSpinning}
            onClick={spin}
            className={`w-full py-5 ${isSpinning ? 'bg-slate-200 cursor-not-allowed' : 'bg-indigo-600 shadow-indigo-200 hover:bg-indigo-700'} text-white rounded-[1.5rem] font-black text-xl shadow-xl transition-all active:scale-95`}
          >
            {isSpinning ? 'Đang quay...' : 'QUAY NGAY'}
          </button>
        )}
      </div>
    </div>
  );
};
