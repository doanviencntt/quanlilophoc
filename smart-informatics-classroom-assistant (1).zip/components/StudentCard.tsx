
import React from 'react';
import { Student } from '../types';

interface StudentCardProps {
  student: Student;
  onUpdatePoints: (studentId: string, amount: number, reason: string) => void;
  onAttendance: (studentId: string, status: 'present' | 'absent' | 'late') => void;
  currentDate: string;
}

export const StudentCard: React.FC<StudentCardProps> = ({ 
  student, 
  onUpdatePoints, 
  onAttendance, 
  currentDate 
}) => {
  const status = student.attendance[currentDate] || 'none';

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-semibold text-slate-800">{student.name}</h3>
          <p className="text-xs text-slate-500">{student.code}</p>
        </div>
        <div className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
          student.points >= 10 ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
        }`}>
          {student.points} pts
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <button 
          onClick={() => onAttendance(student.id, 'present')}
          className={`flex-1 py-1 rounded text-xs transition ${status === 'present' ? 'bg-green-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Có mặt
        </button>
        <button 
          onClick={() => onAttendance(student.id, 'absent')}
          className={`flex-1 py-1 rounded text-xs transition ${status === 'absent' ? 'bg-red-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Vắng
        </button>
        <button 
          onClick={() => onAttendance(student.id, 'late')}
          className={`flex-1 py-1 rounded text-xs transition ${status === 'late' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Muộn
        </button>
      </div>

      <div className="flex gap-2">
        <button 
          onClick={() => onUpdatePoints(student.id, 1, 'Phát biểu đúng')}
          className="flex-1 bg-indigo-50 text-indigo-600 py-1.5 rounded-lg text-sm font-medium hover:bg-indigo-100 transition"
        >
          +1 Thưởng
        </button>
        <button 
          onClick={() => onUpdatePoints(student.id, -1, 'Vi phạm nội quy')}
          className="flex-1 bg-rose-50 text-rose-600 py-1.5 rounded-lg text-sm font-medium hover:bg-rose-100 transition"
        >
          -1 Phạt
        </button>
      </div>
    </div>
  );
};
