
import React, { useState } from 'react';
import { User, ClassGroup, Assignment, Quiz, Student } from '../types';
import { GameQuiz } from './GameQuiz';

interface StudentViewProps {
  user: User;
  classes: ClassGroup[];
  assignments: Assignment[];
  quizzes: Quiz[];
  onCompleteQuiz: (quizId: string, score: number) => void;
}

export const StudentView: React.FC<StudentViewProps> = ({ user, classes, assignments, quizzes, onCompleteQuiz }) => {
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [showAnnouncements, setShowAnnouncements] = useState(false);

  const studentData = classes.flatMap(c => c.students).find(s => s.code === user.studentCode);
  const myClasses = classes.filter(c => c.students.some(s => s.code === user.studentCode));
  const myClass = myClasses[0]; // Assuming student in one main class for demo

  if (activeQuiz) {
    return (
      <div className="max-w-2xl mx-auto py-10">
        <GameQuiz 
          quiz={activeQuiz} 
          onCancel={() => setActiveQuiz(null)} 
          onComplete={(score) => {
            onCompleteQuiz(activeQuiz.id, score);
            setActiveQuiz(null);
          }} 
        />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto pb-20">
      {/* Header Stat Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-8">
          {/* Welcome Card */}
          <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h1 className="text-3xl font-black mb-2 leading-tight">Chào {user.name.split(' ').pop()}! 👋</h1>
                <p className="text-indigo-100 font-medium max-w-md">Tiếp tục hành trình chinh phục Tin học. Hôm nay lớp mình có thử thách mới đấy!</p>
              </div>
              <div className="flex gap-4">
                <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-3xl border border-white/20 text-center">
                  <p className="text-[10px] font-black uppercase opacity-70 mb-1">Cấp độ</p>
                  <p className="text-2xl font-black">Level 5</p>
                </div>
                <div className="bg-amber-400 px-6 py-4 rounded-3xl text-indigo-900 text-center shadow-lg shadow-amber-500/30">
                  <p className="text-[10px] font-black uppercase opacity-70 mb-1">Sao thưởng</p>
                  <p className="text-2xl font-black">⭐ {studentData?.stars || 0}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Weekly Schedule */}
            <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200">
              <h2 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-3">
                <span className="p-2 bg-indigo-50 rounded-xl text-indigo-600">📅</span>
                Lịch học tuần này
              </h2>
              <div className="space-y-4">
                {myClass?.schedules.map(s => (
                  <div key={s.id} className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex flex-col items-center justify-center border border-slate-100">
                      <span className="text-[10px] font-black text-indigo-600 uppercase">T{s.dayOfWeek}</span>
                      <span className="text-xs font-bold text-slate-500">{s.period}</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm">{s.topic}</h4>
                      <p className="text-[10px] text-slate-400 font-medium">{s.room || 'Lab Tin học'}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Assignments & Quizzes */}
            <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200">
              <h2 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-3">
                <span className="p-2 bg-emerald-50 rounded-xl text-emerald-600">⭐</span>
                Nhiệm vụ & Game
              </h2>
              <div className="space-y-4">
                {quizzes.map(quiz => (
                  <div key={quiz.id} className="p-5 bg-indigo-900 text-white rounded-[2rem] shadow-xl relative overflow-hidden group">
                    <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-amber-400 rounded-full opacity-20 group-hover:scale-150 transition-transform duration-700"></div>
                    <div className="relative z-10">
                      <h4 className="font-black text-sm mb-1">{quiz.title}</h4>
                      <p className="text-[10px] text-indigo-300 mb-4 line-clamp-1">{quiz.description}</p>
                      <button 
                        onClick={() => setActiveQuiz(quiz)}
                        className="w-full py-2.5 bg-white text-indigo-900 rounded-xl text-xs font-black hover:bg-amber-400 transition-colors shadow-lg"
                      >
                        Vào Game (Nhận ⭐ {quiz.rewardStars})
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {/* Announcements Sidebar */}
          <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-slate-200">
            <h3 className="text-lg font-black text-slate-800 mb-6 flex items-center justify-between">
              Thông báo mới
              <span className="bg-rose-500 w-2 h-2 rounded-full animate-ping"></span>
            </h3>
            <div className="space-y-6">
              {myClass?.announcements.map(ann => (
                <div key={ann.id} className="relative pl-6 before:absolute before:left-0 before:top-2 before:w-2 before:h-2 before:bg-indigo-500 before:rounded-full">
                  <h4 className={`text-sm font-black mb-1 ${ann.priority === 'high' ? 'text-rose-600' : 'text-slate-800'}`}>{ann.title}</h4>
                  <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">{ann.content}</p>
                  <p className="text-[10px] text-slate-300 mt-2 font-bold">{new Date(ann.date).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Ranking Box */}
          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl">
            <h3 className="text-lg font-black mb-6">Xếp hạng lớp</h3>
            <div className="space-y-4">
              {myClass?.students.sort((a,b) => b.stars - a.stars).slice(0,3).map((s, idx) => (
                <div key={s.id} className="flex items-center gap-3">
                  <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black ${idx === 0 ? 'bg-amber-400 text-slate-900' : 'bg-slate-800 text-slate-400'}`}>
                    #{idx + 1}
                  </span>
                  <span className="flex-1 text-xs font-bold truncate">{s.name}</span>
                  <span className="text-amber-400 font-black text-xs">⭐ {s.stars}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
