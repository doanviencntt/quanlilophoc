
import { ClassGroup, Quiz, Assignment, User } from './types';

export const GRADES = ['10', '11', '12'];

export const DEFAULT_USERS: User[] = [
  // Added required status property
  { id: 'admin-1', name: 'Quản trị viên', email: '227140210014@hpu2.edu.vn', role: 'admin', password: 'admin', status: 'active' },
  { id: 'teacher-1', name: 'Nguyễn Văn Tin', email: 'teacher@school.edu.vn', role: 'teacher', password: '123', status: 'active' }
];

export const INITIAL_CLASSES: ClassGroup[] = [
  {
    id: 'class-1',
    name: '10A1 - Lập trình Python',
    grade: '10',
    teacherId: 'teacher-1',
    students: [
      { id: 's1', name: 'Nguyễn Văn An', code: 'IT1001', points: 10, stars: 5, xp: 450, password: '123', attendance: {} },
      { id: 's2', name: 'Trần Thị Bình', code: 'IT1002', points: 8, stars: 3, xp: 120, password: '123', attendance: {} },
    ],
    announcements: [
      { id: 'ann-1', title: 'Kiểm tra 15p', content: 'Tuần sau lớp sẽ có bài kiểm tra về kiểu dữ liệu List.', date: Date.now(), priority: 'high' }
    ],
    schedules: [
      { id: 'sess-1', dayOfWeek: 2, period: '1-2', topic: 'Cấu trúc rẽ nhánh', room: 'Lab 1' },
      { id: 'sess-2', dayOfWeek: 5, period: '3-4', topic: 'Vòng lặp For', room: 'Lab 2' }
    ]
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz-1',
    title: 'Thử thách Python: Sao Hy Vọng',
    description: 'Vượt qua 3 câu hỏi để nhận 5 sao thưởng.',
    rewardStars: 5,
    questions: [
      { id: 'q1', question: 'Hàm in trong Python là gì?', options: ['printf', 'print', 'log', 'echo'], correctIndex: 1 },
      { id: 'q2', question: 'Python là ngôn ngữ?', options: ['Thông dịch', 'Biên dịch', 'Cả hai', 'Không phải'], correctIndex: 0 },
      { id: 'q3', question: 'Dấu chia lấy dư là?', options: ['/', '//', '%', '^'], correctIndex: 2 }
    ]
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  // Updated to match Assignment interface (removed dueDate, added required startTime, endTime, etc.)
  { 
    id: 'asm-1', 
    title: 'Bài tập 1: Tính diện tích', 
    description: 'Viết chương trình tính diện tích hình tròn.', 
    startTime: Date.now(),
    endTime: Date.now() + 86400000,
    durationMinutes: 45,
    maxScore: 10,
    questions: [],
    classId: 'class-1', 
    type: 'homework', 
    status: 'open' 
  }
];