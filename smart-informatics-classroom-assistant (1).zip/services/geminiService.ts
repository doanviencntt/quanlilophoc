
import { GoogleGenAI } from "@google/genai";

// Fix: Initialized GoogleGenAI strictly using process.env.API_KEY as per guidelines.
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLessonIdeas = async (topic: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Bạn là một trợ lý giáo viên Tin học THPT tại Việt Nam. 
    Hãy gợi ý 3 hoạt động sôi nổi và 1 bài tập thực hành ngắn cho chủ đề: "${topic}". 
    Kết quả trả về định dạng Markdown, ngôn ngữ Tiếng Việt, súc tích, hiện đại.`,
    config: {
      temperature: 0.7,
    }
  });
  return response.text;
};

export const generateCodeChallenge = async (level: string, language: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Tạo một thử thách lập trình ${level} bằng ngôn ngữ ${language} cho học sinh THPT. 
    Thử thách nên có bối cảnh thực tế đời sống. 
    Bao gồm: Đề bài, Gợi ý thuật toán và Bộ test case mẫu.`,
  });
  return response.text;
};
