
export type AttendanceStatus = 'present' | 'absent' | 'late';
export type UserRole = 'admin' | 'teacher' | 'student';
export type UserStatus = 'pending' | 'active' | 'blocked';
export type QuestionType = 'multiple_choice' | 'true_false' | 'short_answer' | 'essay';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  password?: string;
  status: UserStatus; // To approve teachers
  studentCode?: string;
}

export interface Student {
  id: string;
  name: string;
  code: string;
  points: number;
  stars: number;
  xp: number; 
  password?: string;
  attendance: Record<string, AttendanceStatus>;
}

export interface Question {
  id: string;
  type: QuestionType;
  prompt: string;
  options?: string[]; // For multiple choice
  correctAnswer: any; // string, boolean, or array
  points: number;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  startTime: number;
  endTime: number;
  durationMinutes: number;
  maxScore: number;
  classId: string;
  type: 'homework' | 'exam';
  questions: Question[];
  status: 'open' | 'closed';
}

// Added QuizQuestion interface
export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
}

// Added Quiz interface
export interface Quiz {
  id: string;
  title: string;
  description: string;
  rewardStars: number;
  questions: QuizQuestion[];
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: number;
  priority: 'normal' | 'high';
}

export interface LessonSession {
  id: string;
  dayOfWeek: number;
  period: string;
  topic: string;
  room: string;
}

export interface ClassGroup {
  id: string;
  name: string;
  grade: string;
  students: Student[];
  teacherId: string;
  announcements: Announcement[];
  schedules: LessonSession[];
}

export interface ActivityLog {
  id: string;
  timestamp: number;
  type: 'reward' | 'penalty' | 'call' | 'submission' | 'quiz_complete' | 'system' | 'cheat_warning';
  studentId: string;
  studentName: string;
  classId: string;
  points?: number;
  stars?: number;
  reason: string;
}